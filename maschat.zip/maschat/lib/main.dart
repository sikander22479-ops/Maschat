import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: "AIzaSy...",
          appId: "1:...",
          messagingSenderId: "...",
          projectId: "maschat",
          databaseURL: "https://maschat-default-rtdb.firebaseio.com",
        ),
      );
    }
  } catch (e) {
    debugPrint("Firebase init error: $e");
  }
  runApp(const MaschatApp());
}

class MaschatApp extends StatelessWidget {
  const MaschatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Maschat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        useMaterial3: true,
      ),
      home: const MaschatDashboard(),
    );
  }
}

class MaschatDashboard extends StatefulWidget {
  const MaschatDashboard({super.key});

  @override
  State<MaschatDashboard> createState() => _MaschatDashboardState();
}

class _MaschatDashboardState extends State<MaschatDashboard> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    MaschatChatScreen(),
    MaschatMeetingScreen(),
    MaschatCallsScreen(),
    MaschatAboutScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: 'Chats',
          ),
          NavigationDestination(
            icon: Icon(Icons.videocam_outlined),
            selectedIcon: Icon(Icons.videocam),
            label: 'Meetings',
          ),
          NavigationDestination(
            icon: Icon(Icons.call_outlined),
            selectedIcon: Icon(Icons.call),
            label: 'Calls',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Owner',
          ),
        ],
      ),
    );
  }
}

// 1. CHAT & MEDIA / PDF SHARING SCREEN
class MaschatChatScreen extends StatefulWidget {
  const MaschatChatScreen({super.key});

  @override
  State<MaschatChatScreen> createState() => _MaschatChatScreenState();
}

class _MaschatChatScreenState extends State<MaschatChatScreen> {
  final TextEditingController _msgCtrl = TextEditingController();
  late final DatabaseReference _dbRef;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _dbRef = FirebaseDatabase.instance.ref().child('maschat_global_room/messages');
  }

  void _send({String? text, String? mediaName, bool isPdf = false}) {
    if (text != null && text.trim().isEmpty && mediaName == null) return;
    _dbRef.push().set({
      'sender': 'Sikander Singh',
      'text': text ?? '',
      'mediaName': mediaName ?? '',
      'isMedia': mediaName != null && mediaName.isNotEmpty,
      'isPdf': isPdf,
      'time': ServerValue.timestamp,
    });
    _msgCtrl.clear();
  }

  Future<void> _pickImage() async {
    XFile? file = await _picker.pickImage(source: ImageSource.gallery);
    if (file != null) {
      _send(text: 'Photo Shared', mediaName: file.name, isPdf: false);
    }
  }

  Future<void> _pickPdf() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (result != null) {
      _send(text: 'PDF Plan Shared', mediaName: result.files.single.name, isPdf: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Maschat Chats', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.deepPurple)),
        backgroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder(
              stream: _dbRef.onValue,
              builder: (context, AsyncSnapshot<DatabaseEvent> snap) {
                if (!snap.hasData || snap.data!.snapshot.value == null) {
                  return const Center(child: Text('No messages yet. Start chatting!'));
                }
                Map vals = snap.data!.snapshot.value as Map;
                List list = vals.values.toList();
                list.sort((a, b) => (a['time'] ?? 0).compareTo(b['time'] ?? 0));

                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  itemBuilder: (context, i) {
                    var m = list[i];
                    bool hasMedia = m['isMedia'] ?? false;
                    bool isPdf = m['isPdf'] ?? false;
                    String mediaName = m['mediaName'] ?? '';

                    return Align(
                      alignment: Alignment.centerLeft,
                      child: Card(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(m['sender'] ?? 'User', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                              const SizedBox(height: 4),
                              if (hasMedia)
                                Row(
                                  children: [
                                    Icon(isPdf ? Icons.picture_as_pdf : Icons.image, color: Colors.deepPurple),
                                    const SizedBox(width: 8),
                                    Text(mediaName, style: const TextStyle(fontWeight: FontWeight.w500)),
                                  ],
                                ),
                              if (m['text'] != null && m['text'].toString().isNotEmpty)
                                Text(m['text']),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            color: Colors.white,
            child: Row(
              children: [
                IconButton(icon: const Icon(Icons.image, color: Colors.deepPurple), onPressed: _pickImage),
                IconButton(icon: const Icon(Icons.picture_as_pdf, color: Colors.deepPurple), onPressed: _pickPdf),
                Expanded(
                  child: TextField(
                    controller: _msgCtrl,
                    decoration: const InputDecoration(hintText: 'Type a message...', border: InputBorder.none),
                    onSubmitted: (v) => _send(text: v),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.deepPurple),
                  onPressed: () => _send(text: _msgCtrl.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// 2. MEETINGS SCREEN
class MaschatMeetingScreen extends StatelessWidget {
  const MaschatMeetingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Maschat Meetings', style: TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.video_call, size: 80, color: Colors.deepPurple),
            const SizedBox(height: 16),
            const Text('Host Live Meetings & Share PDF Plans', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
            const SizedBox(height: 24),
            ElevatedButton.styleFrom.hashCode == 0 ? Container() : ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Starting Meeting Room...')));
              },
              child: const Text('Start Meeting'),
            ),
          ],
        ),
      ),
    );
  }
}

// 3. CALLS SCREEN
class MaschatCallsScreen extends StatelessWidget {
  const MaschatCallsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Maschat Calls', style: TextStyle(color: Colors.deepPurple)), backgroundColor: Colors.white),
      body: const Center(child: Text('Audio & Video Calls History')),
    );
  }
}

// 4. OWNER / ABOUT SCREEN
class MaschatAboutScreen extends StatelessWidget {
  const MaschatAboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About Maschat', style: TextStyle(color: Colors.deepPurple)), backgroundColor: Colors.white),
      body: const Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            CircleAvatar(radius: 50, backgroundColor: Colors.deepPurple, child: Icon(Icons.person, size: 60, color: Colors.white)),
            SizedBox(height: 16),
            Text('Maschat App', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
            SizedBox(height: 8),
            Text('Founder & Owner', style: TextStyle(fontSize: 16, color: Colors.grey)),
            SizedBox(height: 4),
            Text('Sikander Singh', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Divider(height: 40),
            ListTile(leading: Icon(Icons.location_on, color: Colors.deepPurple), title: Text('Location'), trailing: Text('Gurdaspur, Punjab')),
          ],
        ),
      ),
    );
  }
}