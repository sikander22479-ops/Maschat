package com.example.doclechat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
